# Respuestas ejercicios deber

Actualizaremos esta parte luego de la fecha de entrega del deber 

```{image} ./img/suc.gif
:alt: ./img/suc.gif
:width: 250px
:align: center
```

